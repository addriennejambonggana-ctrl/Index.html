GREG - ONE-PAGE PERSONAL PORTFOLIO

FILES
- index.html
- css/style.css
- assets/ (put your teacher-provided project thumbnails here)

HOW TO OPEN
1. Extract the ZIP file.
2. Open the Greg-Portfolio folder.
3. Double-click index.html to view it in your browser.
4. Internet is needed to load Bootstrap 5 from its CDN.

IMPORTANT: PROJECT THUMBNAILS
The assignment says to use only visual assets supplied by your instructor.
Copy your instructor-provided thumbnails into the assets folder and rename them:
- project-walk-cycle.jpg
- project-pen-animation.jpg

If your teacher supplied PNG or SVG files, update the image filenames in index.html
to match the exact filenames. Do not use invented project images.

EDIT YOUR DETAILS
Open index.html in VS Code or another text editor. Check the name, course,
school, year level, skills, project descriptions, and contact placeholder.
Replace any detail that is not accurate for you.

NOTE ABOUT JAVASCRIPT
The assignment says no JavaScript is required. The Bootstrap bundle script at
the bottom is included only to make the mobile navigation toggle work.
If your instructor interprets the rule as no JavaScript at all, remove that
script and keep the navigation links visible or use a CSS-only menu.
